package projetoGsSunecs.resources;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import projetoGsSunecs.controller.UsuarioController;
import projetoGsSunecs.model.bo.UsuarioBO;
import projetoGsSunecs.model.vo.Usuario;
import projetoGsSunecs.view.MensagemView;


@Path("/usuario") //nome da página
public class UsuarioResource{
	// alt + shif + r para selecionar tudo ao msm tempo
	//o endpoint chama o controller passando a BO e a View
	private UsuarioBO usuarioBO = new UsuarioBO();
	private MensagemView mensagemView = new MensagemView();	
	private UsuarioController usuarioController = new UsuarioController(usuarioBO, mensagemView);
	
	//inserir (POST)
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cadastroRs(Usuario usuario, @Context UriInfo uriInfo) {
		//usuarioBO.inserirBO(usuario);
		usuarioController.salvarUsuario(usuario);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder(); //recebe a informação do front (página)
		builder.path(Integer.toString(usuario.getId_usu())); //identifica o id do campo (String)
		return Response.created(builder.build()).build(); //composição -> caminho (carrregar o que foi carregado) - http -> 200
	}
	
	//atualizar (PUT)
	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response atualizaRs(Usuario usuario, @PathParam("id") int id) {
		//usuarioBO.atualizarBO(usuario, id);
		usuarioController.atualizarUsuario(usuario, id);
		return Response.ok().build();
	}
	
	//deletar (DELETE)
	@DELETE
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deletarRs(@PathParam("id") int id) {
		//usuarioBO.deletarBO(id);
		usuarioController.deletarUsuario(id);
		return Response.ok().build();
	}
	
	//consultar (GET)
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Usuario> selecionarRs() {
		//return (ArrayList<Usuario>) usuarioBO.selecionarBO();
		return (ArrayList<Usuario>) usuarioController.listarUsuario();
	}
}
