package projetoGsSunecs.resources;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import projetoGsSunecs.controller.EmpresaController;
import projetoGsSunecs.model.bo.EmpresaBO;
import projetoGsSunecs.model.vo.Empresa;
import projetoGsSunecs.view.MensagemView;

@Path("/empresa")
public class EmpresaResource {

	private EmpresaBO empresaBO = new EmpresaBO();
	private MensagemView mensagemView = new MensagemView();	
	private EmpresaController empresaController = new EmpresaController(empresaBO, mensagemView);

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cadastroRs(Empresa empresa, @Context UriInfo uriInfo) {
        //empresaBO.inserirBO(empresa);
    	empresaController.salvarEmpresa(empresa);
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(empresa.getId_empre()));
        return Response.created(builder.build()).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizaRs(Empresa empresa, @PathParam("id") int id) {
        //empresaBO.atualizarBO(empresa, id);
    	empresaController.atualizarEmpresa(empresa, id);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deletarRs(@PathParam("id") int id) {
        //empresaBO.deletarBO(id);
    	empresaController.deletarEmpresa(id);
        return Response.ok().build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Empresa> selecionarRs() {
        //return (ArrayList<Empresa>) empresaBO.selecionarBO();
    	return (ArrayList<Empresa>) empresaController.listarEmpresa();
    }
}
