package projetoGsSunecs.resources;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import projetoGsSunecs.controller.ConsultaController;
import projetoGsSunecs.model.bo.ConsultaBO;
import projetoGsSunecs.model.vo.Consulta;
import projetoGsSunecs.view.MensagemView;

@Path("/consulta")
public class ConsultaResource {

	private ConsultaBO consultaBO = new ConsultaBO();
	private MensagemView mensagemView = new MensagemView();	
	private ConsultaController consultaController = new ConsultaController(consultaBO, mensagemView);

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cadastroRs(Consulta consulta, @Context UriInfo uriInfo) {
        //consultaBO.inserirBO(consulta);
    	consultaController.salvarConsulta(consulta);
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(consulta.getId_con()));
        return Response.created(builder.build()).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizaRs(Consulta consulta, @PathParam("id") int id) {
        //consultaBO.atualizarBO(consulta, id);
    	consultaController.atualizarConsulta(consulta, id);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deletarRs(@PathParam("id") int id) {
        //consultaBO.deletarBO(id);
    	consultaController.deletarConsulta(id);
        return Response.ok().build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Consulta> selecionarRs() {
        //return (ArrayList<Consulta>) consultaBO.selecionarBO();
    	return (ArrayList<Consulta>) consultaController.listarConsulta();
    }
}
