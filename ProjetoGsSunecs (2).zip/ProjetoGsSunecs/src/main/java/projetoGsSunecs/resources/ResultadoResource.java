package projetoGsSunecs.resources;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import projetoGsSunecs.controller.ResultadoController;
import projetoGsSunecs.model.bo.ResultadoBO;
import projetoGsSunecs.model.vo.Resultado;
import projetoGsSunecs.view.MensagemView;

@Path("/resultado")
public class ResultadoResource {

	private ResultadoBO resultadoBO = new ResultadoBO();
	private MensagemView mensagemView = new MensagemView();	
	private ResultadoController resultadoController = new ResultadoController(resultadoBO, mensagemView);

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cadastroRs(Resultado resultado, @Context UriInfo uriInfo) {
        //resultadoBO.inserirBO(resultado);
    	resultadoController.salvarResultado(resultado);
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(resultado.getId_resul()));
        return Response.created(builder.build()).build();
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizaRs(Resultado resultado, @PathParam("id") int id) {
        //resultadoBO.atualizarBO(resultado, id);
    	resultadoController.atualizarResultado(resultado, id);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deletarRs(@PathParam("id") int id) {
        //resultadoBO.deletarBO(id);
    	resultadoController.deletarResultado(id);
        return Response.ok().build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Resultado> selecionarRs() {
        //return (ArrayList<Resultado>) resultadoBO.selecionarBO();
    	return (ArrayList<Resultado>) resultadoController.listarResultado();
    }
}

