package projetoGsSunecs.model.bo;

import java.util.ArrayList;

import projetoGsSunecs.model.dao.EmpresaDAO;
import projetoGsSunecs.model.vo.Empresa;

public class EmpresaBO {
    
    EmpresaDAO empresaDAO = null;

    // Inserir
   
    public boolean inserirBO(Empresa empresa) {
        EmpresaDAO empresaDAO = new EmpresaDAO();
        ArrayList<Empresa> empresas = (ArrayList<Empresa>) empresaDAO.listar();

        boolean retornoDao = false;
        
        // Converte o telefone (int) para String
        
        // Verificar se o telefone tem exatamente 11 dígitos
        if (empresa.getTel_empre() != null && empresa.getTel_empre().length() == 11) {
            // Verificar se o CNPJ tem exatamente 14 dígitos
            if (empresa.getCnpj_empre() != null && empresa.getCnpj_empre().length() == 14) {
                // Verificar se o CNPJ já está cadastrado
                boolean cnpjExistente = false;
                for (Empresa e : empresas) {
                    if (e.getCnpj_empre().equals(empresa.getCnpj_empre())) {
                        cnpjExistente = true;
                        break;
                    }
                }

                if (!cnpjExistente) {
                	retornoDao = empresaDAO.inserir(empresa);
                	return retornoDao;
                } else {
                    System.out.println("Erro: O CNPJ informado já está cadastrado.");
                }
            } else {
                System.out.println("Erro: O CNPJ deve conter exatamente 14 dígitos.");
            }
        } else {
            System.out.println("Erro: O telefone deve conter exatamente 11 dígitos.");
        }
        return retornoDao;
    }


    // Atualizar
    public boolean atualizarBO(Empresa empresa, int id) {
        EmpresaDAO empresaDAO = new EmpresaDAO();
        boolean retornoDao = empresaDAO.atualizar(empresa, id);
        return retornoDao;
    }

    // Deletar
    public boolean deletarBO(int id) {
        EmpresaDAO empresaDAO = new EmpresaDAO();
        boolean retornoDao = empresaDAO.deletar(id);
        return retornoDao;
    }

    // Selecionar
    public ArrayList<Empresa> selecionarBO() {
        EmpresaDAO empresaDAO = new EmpresaDAO();
        return (ArrayList<Empresa>) empresaDAO.listar();
    }
}
