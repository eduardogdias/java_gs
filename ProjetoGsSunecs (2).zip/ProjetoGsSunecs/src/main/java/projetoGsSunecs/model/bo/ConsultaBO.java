package projetoGsSunecs.model.bo;

import java.util.ArrayList;

import projetoGsSunecs.model.dao.ConsultaDAO;
import projetoGsSunecs.model.vo.Consulta;

public class ConsultaBO {
    
    ConsultaDAO consultaDAO = null;

    // Inserir
    public boolean inserirBO(Consulta consulta) {
        ConsultaDAO consultaDAO = new ConsultaDAO();
        boolean retornoDao = consultaDAO.inserir(consulta);
        return retornoDao;
    }

    // Atualizar
    public boolean atualizarBO(Consulta consulta, int id) {
        ConsultaDAO consultaDAO = new ConsultaDAO();
        boolean retornoDao = consultaDAO.atualizar(consulta, id);
        return retornoDao;
    }

    // Deletar
    public boolean deletarBO(int id) {
        ConsultaDAO consultaDAO = new ConsultaDAO();
        boolean retornoDao = consultaDAO.deletar(id);
		return retornoDao;
    }

    // Selecionar
    public ArrayList<Consulta> selecionarBO() {
        ConsultaDAO consultaDAO = new ConsultaDAO();
        return (ArrayList<Consulta>) consultaDAO.listar();
    }
}
