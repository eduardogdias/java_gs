package projetoGsSunecs.model.bo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import projetoGsSunecs.model.dao.ResultadoDAO;
import projetoGsSunecs.model.vo.Consulta;
import projetoGsSunecs.model.vo.Resultado;

public class ResultadoBO {
    
	
    ResultadoDAO resultadoDAO = null;
    
    // Inserir
    public boolean inserirBO(Resultado resultado) {
        ResultadoDAO resultadoDAO = new ResultadoDAO();
        boolean retornoDao = resultadoDAO.inserir(resultado);
        return retornoDao;
    }
    
    public static boolean inserirCalcBO(Resultado resultado) {
        ResultadoDAO resultadoDAO = new ResultadoDAO();
        boolean retornoDao = resultadoDAO.inserir(resultado);
        return retornoDao;
    }

    // Atualizar
    public boolean atualizarBO(Resultado resultado, int id) {
        ResultadoDAO resultadoDAO = new ResultadoDAO();
        boolean retornoDao = resultadoDAO.atualizar(resultado, id);
        return retornoDao;
    }

    // Deletar
    public boolean deletarBO(int id) {
        ResultadoDAO resultadoDAO = new ResultadoDAO();
        boolean retornoDao = resultadoDAO.deletar(id);
        return retornoDao;
    }

    // Selecionar
    public ArrayList<Resultado> selecionarBO() {
        ResultadoDAO resultadoDAO = new ResultadoDAO();
        return (ArrayList<Resultado>) resultadoDAO.listar();
    }
    
    
    
    public static void calculoBO(Consulta consulta) {
    	// valores padrões para os cálculos
    	System.out.println("Entrou no bo");
    	double dimensao_painel_padrao = 1.6 * 1.0; // 1.6m x 1.0m
		double geracao_painel_padrao = 600; // kWh/mês
		double custo_painel = 400; // R$
		double custo_instalacao = 50; // R$ por painel
		
		
		double areaDisponivel = consulta.getLarg_area_con() * consulta.getCompri_area_con();
        int quantidadePaineis = (int) (areaDisponivel / dimensao_painel_padrao);
        double capacidadeGeracao = quantidadePaineis * geracao_painel_padrao;

        double economiaMensal = (capacidadeGeracao / consulta.getConsumo_mensal_kwh_con()) * consulta.getGasto_mensal_reais_con();
        double custoTotal = (quantidadePaineis * custo_painel) + (quantidadePaineis * custo_instalacao);
        int roiMeses = (int) Math.ceil(custoTotal / economiaMensal);

        
        
        
        Resultado resultado = new Resultado();
        
        //máscara de duas casa decimais e converte para double
        BigDecimal capacidadeGeracaoBD = new BigDecimal(capacidadeGeracao).setScale(2, RoundingMode.HALF_UP);
        BigDecimal economiaMensalBD = new BigDecimal(economiaMensal).setScale(2, RoundingMode.HALF_UP);
        BigDecimal custoTotalBD = new BigDecimal(custoTotal).setScale(2, RoundingMode.HALF_UP);
        
        
        resultado.setQuantidade_paineis_resul(quantidadePaineis);
        resultado.setGeracao_kwh_resul(capacidadeGeracaoBD.doubleValue());
        resultado.setEconomia_reais_resul(economiaMensalBD.doubleValue());
        resultado.setRoi_resul(roiMeses);
        resultado.setCusto_tot_resul(custoTotalBD.doubleValue());
        resultado.setFk_con(18);
        
        
        
        
        System.out.println("Geração: " + resultado.getGeracao_kwh_resul());
        System.out.println("N° Paineis: " + resultado.getQuantidade_paineis_resul());
        System.out.println("Economia R$: " + resultado.getEconomia_reais_resul());
        System.out.println("Roi (meses): " + resultado.getRoi_resul());
        System.out.println("Custo R$: " + resultado.getCusto_tot_resul());
        System.out.println("Conta FK: " + resultado.getFk_con());
       	
        
        
        inserirCalcBO(resultado);
     
        
    }
}
