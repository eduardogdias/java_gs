package projetoGsSunecs.model.bo;

import java.util.ArrayList;

import projetoGsSunecs.model.dao.UsuarioDAO;
import projetoGsSunecs.model.vo.Usuario;



public class UsuarioBO {
	
UsuarioDAO usuarioDAO = null;
	
	//inserir
	public boolean inserirBO(Usuario usuario) {
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		ArrayList<Usuario> usuarios = (ArrayList<Usuario>) usuarioDAO.listar();

		boolean retornoDao = false;
		
		// Verificar se o e-mail já existe
		boolean emailExistente = false;
		for (Usuario u : usuarios) {
			if (u.getEmail_usu().equalsIgnoreCase(usuario.getEmail_usu())) {
				emailExistente = true;
				break;
			}
		}

		if (!emailExistente) {
			// Verificar se o CEP tem exatamente 8 dígitos
			if (usuario.getCep_usu() != null && usuario.getCep_usu().length() == 8) {
				retornoDao = usuarioDAO.inserir(usuario);
				return retornoDao;
			} else {
				System.out.println("Erro: O CEP deve conter exatamente 8 dígitos.");
			}
		} else {
			System.out.println("Erro: O e-mail informado já está cadastrado.");
		}
		return retornoDao;
	}
	
	
	
	//atualizar
	public boolean atualizarBO(Usuario usuario, int id) {
		UsuarioDAO usuarioDAO = new UsuarioDAO();		
		boolean retornoDao = usuarioDAO.atualizar(usuario, id);
		return retornoDao;
	}
	
	//deletar
	public boolean deletarBO(int id) {
		UsuarioDAO usuarioDAO = new UsuarioDAO();		
		boolean retornoDao = usuarioDAO.deletar(id);
		return retornoDao;
	}
	
	//selecionar
	public ArrayList<Usuario> selecionarBO() {
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		return (ArrayList<Usuario>) usuarioDAO.listar();
	}

}
