package projetoGsSunecs.model.bo;

import java.util.ArrayList;

import projetoGsSunecs.model.dao.PainelDAO;
import projetoGsSunecs.model.vo.Painel;

public class PainelBO {
    
    PainelDAO painelDAO = null;

    // Inserir
    public boolean inserirBO(Painel painel) {
        PainelDAO painelDAO = new PainelDAO();
        boolean retornoDao = painelDAO.inserir(painel);
        return retornoDao;
    }

    // Atualizar
    public boolean atualizarBO(Painel painel, int id) {
        PainelDAO painelDAO = new PainelDAO();
        boolean retornoDao = painelDAO.atualizar(painel, id);
        return retornoDao;
    }

    // Deletar
    public boolean deletarBO(int id) {
        PainelDAO painelDAO = new PainelDAO();
        boolean retornoDao = painelDAO.deletar(id);
        return retornoDao;
    }

    // Selecionar
    public ArrayList<Painel> selecionarBO() {
        PainelDAO painelDAO = new PainelDAO();
        return (ArrayList<Painel>) painelDAO.listar();
    }
}
