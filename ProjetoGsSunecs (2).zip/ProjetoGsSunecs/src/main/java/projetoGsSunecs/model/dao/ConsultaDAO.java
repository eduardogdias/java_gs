package projetoGsSunecs.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import projetoGsSunecs.conexao.Conexao;
import projetoGsSunecs.model.vo.Consulta;

public class ConsultaDAO {

    public Connection minhaConexao;
    Conexao conn = new Conexao();
    
    public ConsultaDAO() {
        //this.minhaConexao = new Conexao().abrirConexao();
    }

    public boolean inserir(Consulta consulta) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "INSERT INTO consulta (consumo_mensal_kwh_con, gasto_mensal_reais_con, larg_area_con, compri_area_con, fk_usu) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setDouble(1, consulta.getConsumo_mensal_kwh_con());
            stmt.setDouble(2, consulta.getGasto_mensal_reais_con());
            stmt.setDouble(3, consulta.getLarg_area_con());
            stmt.setDouble(4, consulta.getCompri_area_con());
            stmt.setInt(5, consulta.getFk_usu());
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean deletar(int id) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "DELETE FROM consulta WHERE id_con = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
            } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean atualizar(Consulta consulta, int id) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "UPDATE consulta SET consumo_mensal_kwh_con = ?, gasto_mensal_reais_con = ?, larg_area_con = ?, compri_area_con = ?, fk_usu = ? WHERE id_con = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setDouble(1, consulta.getConsumo_mensal_kwh_con());
            stmt.setDouble(2, consulta.getGasto_mensal_reais_con());
            stmt.setDouble(3, consulta.getLarg_area_con());
            stmt.setDouble(4, consulta.getCompri_area_con());
            stmt.setInt(5, consulta.getFk_usu());
            stmt.setInt(6, id);
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
            } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public List<Consulta> listar() {
    	this.minhaConexao = new Conexao().abrirConexao();
        List<Consulta> listaConsulta = new ArrayList<>();
        String sql = "SELECT * FROM consulta";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Consulta consulta = new Consulta();
                consulta.setId_con(rs.getInt("id_con"));
                consulta.setConsumo_mensal_kwh_con(rs.getDouble("consumo_mensal_kwh_con"));
                consulta.setGasto_mensal_reais_con(rs.getDouble("gasto_mensal_reais_con"));
                consulta.setLarg_area_con(rs.getDouble("larg_area_con"));
                consulta.setCompri_area_con(rs.getDouble("compri_area_con"));
                consulta.setFk_usu(rs.getInt("fk_usu"));

                listaConsulta.add(consulta);
            }
            return listaConsulta;

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao listar");
            return null;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }
}
