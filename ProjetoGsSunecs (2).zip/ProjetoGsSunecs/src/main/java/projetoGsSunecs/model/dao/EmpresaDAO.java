package projetoGsSunecs.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import projetoGsSunecs.conexao.Conexao;
import projetoGsSunecs.model.vo.Empresa;

public class EmpresaDAO {

    public Connection minhaConexao;
    Conexao conn = new Conexao();
    
    public EmpresaDAO() {
       // this.minhaConexao = new Conexao().abrirConexao();
		//this.minhaConexao = conn.abrirConexao();

    }

    public boolean inserir(Empresa empresa) {
    	this.minhaConexao = conn.abrirConexao();
        String sql = "INSERT INTO empresa (nome_empre, endereco_empre, tel_empre, cnpj_empre, valor_empre) VALUES (?, ?, ?, ?, ?)";
        
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setString(1, empresa.getNome_empre());
            stmt.setString(2, empresa.getEndereco_empre());
            stmt.setString(3, empresa.getTel_empre());
            stmt.setString(4, empresa.getCnpj_empre());
            stmt.setDouble(5, empresa.getValor_empre());
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
            } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean deletar(int id) {
    	this.minhaConexao = conn.abrirConexao();
        String sql = "DELETE FROM empresa WHERE id_empre = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean atualizar(Empresa empresa, int id) {
    	this.minhaConexao = conn.abrirConexao();
        String sql = "UPDATE empresa SET nome_empre = ?, endereco_empre = ?, tel_empre = ?, cnpj_empre = ?, valor_empre = ? WHERE id_empre = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setString(1, empresa.getNome_empre());
            stmt.setString(2, empresa.getEndereco_empre());
            stmt.setString(3, empresa.getTel_empre());
            stmt.setString(4, empresa.getCnpj_empre());
            stmt.setDouble(5, empresa.getValor_empre());
            stmt.setInt(6, id);
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public List<Empresa> listar() {
    	this.minhaConexao = conn.abrirConexao();
        List<Empresa> listaEmpresa = new ArrayList<>();
        String sql = "SELECT * FROM empresa";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Empresa empresa = new Empresa();
                empresa.setId_empre(rs.getInt("id_empre"));
                empresa.setNome_empre(rs.getString("nome_empre"));
                empresa.setEndereco_empre(rs.getString("endereco_empre"));
                empresa.setTel_empre(rs.getString("tel_empre"));
                empresa.setCnpj_empre(rs.getString("cnpj_empre"));
                empresa.setValor_empre(rs.getDouble("valor_empre"));            
                listaEmpresa.add(empresa);
                
            }
            return listaEmpresa;

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao listar");
            return null;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }
}
