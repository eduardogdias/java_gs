package projetoGsSunecs.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import projetoGsSunecs.conexao.Conexao;
import projetoGsSunecs.model.vo.Resultado;

public class ResultadoDAO {

    public Connection minhaConexao;
    Conexao conn = new Conexao();
    
    public ResultadoDAO() {
        //this.minhaConexao = new Conexao().abrirConexao();
    }

    public boolean inserir(Resultado resultado) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "INSERT INTO resultado (quantidade_paineis_resul, geracao_kwh_resul, economia_reais_resul, roi_resul, custo_tot_resul, fk_con) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setInt(1, resultado.getQuantidade_paineis_resul());
            stmt.setDouble(2, resultado.getGeracao_kwh_resul());
            stmt.setDouble(3, resultado.getEconomia_reais_resul());
            stmt.setInt(4, resultado.getRoi_resul());
            stmt.setDouble(5, resultado.getCusto_tot_resul());
            stmt.setInt(6, resultado.getFk_con());
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean deletar(int id) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "DELETE FROM resultado WHERE id_resul = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean atualizar(Resultado resultado, int id) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "UPDATE resultado SET quantidade_paineis_resul = ?, geracao_kwh_resul = ?, economia_reais_resul = ?, roi_resul = ?, custo_tot_resul = ?, fk_con = ? WHERE id_resul = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setInt(1, resultado.getQuantidade_paineis_resul());
            stmt.setDouble(2, resultado.getGeracao_kwh_resul());
            stmt.setDouble(3, resultado.getEconomia_reais_resul());
            stmt.setInt(4, resultado.getRoi_resul());
            stmt.setDouble(5, resultado.getCusto_tot_resul());
            stmt.setInt(6, resultado.getFk_con());
            stmt.setInt(7, id);
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public List<Resultado> listar() {
    	this.minhaConexao = new Conexao().abrirConexao();
        List<Resultado> listaResultado = new ArrayList<>();
        String sql = "SELECT * FROM resultado";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Resultado resultado = new Resultado();
                resultado.setId_resul(rs.getInt("id_resul"));
                resultado.setQuantidade_paineis_resul(rs.getInt("quantidade_paineis_resul"));
                resultado.setGeracao_kwh_resul(rs.getDouble("geracao_kwh_resul"));
                resultado.setEconomia_reais_resul(rs.getDouble("economia_reais_resul"));
                resultado.setRoi_resul(rs.getInt("roi_resul"));
                resultado.setCusto_tot_resul(rs.getDouble("custo_tot_resul"));
                resultado.setFk_con(rs.getInt("fk_con"));

                listaResultado.add(resultado);
            }
            return listaResultado;

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao listar");
            return null;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }
}
