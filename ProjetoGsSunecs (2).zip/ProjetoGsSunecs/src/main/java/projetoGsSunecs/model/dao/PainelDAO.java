package projetoGsSunecs.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import projetoGsSunecs.conexao.Conexao;
import projetoGsSunecs.model.vo.Painel;

public class PainelDAO {

    public Connection minhaConexao;
    Conexao conn = new Conexao();

    public PainelDAO() {
        //this.minhaConexao = new Conexao().abrirConexao();
    }

    public boolean inserir(Painel painel) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "INSERT INTO painel (comprimento, largura, potencia, preco, fk_empre) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setDouble(1, painel.getComprimento());
            stmt.setDouble(2, painel.getLargura());
            stmt.setDouble(3, painel.getPotencia());
            stmt.setDouble(4, painel.getPreco());
            stmt.setInt(5, painel.getFk_empre());
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
            } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean deletar(int id) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "DELETE FROM painel WHERE id_painel = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public boolean atualizar(Painel painel, int id) {
    	this.minhaConexao = new Conexao().abrirConexao();
        String sql = "UPDATE painel SET comprimento = ?, largura = ?, potencia = ?, preco = ?, fk_empre = ? WHERE id_painel = ?";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            stmt.setDouble(1, painel.getComprimento());
            stmt.setDouble(2, painel.getLargura());
            stmt.setDouble(3, painel.getPotencia());
            stmt.setDouble(4, painel.getPreco());
            stmt.setInt(5, painel.getFk_empre());
            stmt.setInt(6, id);
            stmt.executeUpdate();
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }

    public List<Painel> listar() {
    	this.minhaConexao = new Conexao().abrirConexao();
        List<Painel> listaPainel = new ArrayList<>();
        String sql = "SELECT * FROM painel";
        try {
            PreparedStatement stmt = minhaConexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Painel painel = new Painel();
                painel.setId_painel(rs.getInt("id_painel"));
                painel.setComprimento(rs.getDouble("comprimento"));
                painel.setLargura(rs.getDouble("largura"));
                painel.setPotencia(rs.getDouble("potencia"));
                painel.setPreco(rs.getDouble("preco"));
                painel.setFk_empre(rs.getInt("fk_empre"));

                listaPainel.add(painel);
            }
            return listaPainel;

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao listar");
            return null;
        } finally {
			conn.fecharConexao(minhaConexao);
		}
    }
}
