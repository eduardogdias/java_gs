package projetoGsSunecs.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import projetoGsSunecs.conexao.Conexao;
import projetoGsSunecs.model.vo.Usuario;

public class UsuarioDAO {

	public Connection minhaConexao;
	
	Conexao conn = new Conexao();
	
	public UsuarioDAO() {
		//this.minhaConexao = new Conexao().abrirConexao();
		//this.minhaConexao = conn.abrirConexao();
	}

	// Insert
	public boolean inserir(Usuario usuario) {
		
		this.minhaConexao = conn.abrirConexao();
		String sql = "INSERT INTO usuario (nome_usu, email_usu, cep_usu) VALUES (?, ?, ?)";
		try {
			PreparedStatement stmt = minhaConexao.prepareStatement(sql);
			stmt.setString(1, usuario.getNome_usu());
			stmt.setString(2, usuario.getEmail_usu());
			stmt.setString(3, usuario.getCep_usu());
			stmt.execute();
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			conn.fecharConexao(minhaConexao);
		}
	}

	// Delete
	public boolean deletar(int id) {

		this.minhaConexao = conn.abrirConexao();
		String sql = "DELETE FROM usuario WHERE id_usu = ?";
		try {
			PreparedStatement stmt = minhaConexao.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.execute();
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			conn.fecharConexao(minhaConexao);
		}
	}

	// UpDate
	public boolean atualizar(Usuario usuario, int id) {

		this.minhaConexao = conn.abrirConexao();
		String sql = "UPDATE usuario SET nome_usu = ?, email_usu = ?, cep_usu = ? where id_usu = ?";
		try {
			PreparedStatement stmt = minhaConexao.prepareStatement(sql);
			stmt.setString(1, usuario.getNome_usu());
			stmt.setString(2, usuario.getEmail_usu());
			stmt.setString(3, usuario.getCep_usu());
			stmt.setInt(4, id);
			stmt.executeUpdate();
			stmt.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			conn.fecharConexao(minhaConexao);
		}
	}

	// Select
	public List<Usuario> listar() {

		this.minhaConexao = conn.abrirConexao();
		List<Usuario> listaUsuario = new ArrayList<Usuario>();
		String sql = "SELECT * FROM usuario";

		try {
			PreparedStatement stmt = minhaConexao.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Usuario usuario = new Usuario();
				usuario.setId_usu(rs.getInt("id_usu"));
				usuario.setNome_usu(rs.getString("nome_usu"));
				usuario.setEmail_usu(rs.getString("email_usu"));
				usuario.setCep_usu(rs.getString("cep_usu"));

				listaUsuario.add(usuario);
			}
			return listaUsuario;

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro ao listar");

			return null;
		} finally {
			conn.fecharConexao(minhaConexao);
		}
	}

}
