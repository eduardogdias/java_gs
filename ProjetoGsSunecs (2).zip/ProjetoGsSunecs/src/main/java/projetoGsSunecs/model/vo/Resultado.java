package projetoGsSunecs.model.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Resultado {
	
    private int id_resul;
    private int quantidade_paineis_resul;
    private double geracao_kwh_resul;
    private double economia_reais_resul;
    private int roi_resul;
    private double custo_tot_resul;
    private int fk_con;

    public Resultado() {}

    public Resultado(int id_resul, int quantidade_paineis_resul, double geracao_kwh_resul, double economia_reais_resul, int roi_resul, double custo_tot_resul, int fk_con) {
        this.id_resul = id_resul;
        this.quantidade_paineis_resul = quantidade_paineis_resul;
        this.geracao_kwh_resul = geracao_kwh_resul;
        this.economia_reais_resul = economia_reais_resul;
        this.roi_resul = roi_resul;
        this.custo_tot_resul = custo_tot_resul;
        this.fk_con = fk_con;
    }

    public int getId_resul() {
        return id_resul;
    }

    public void setId_resul(int id_resul) {
        this.id_resul = id_resul;
    }

    public int getQuantidade_paineis_resul() {
        return quantidade_paineis_resul;
    }

    public void setQuantidade_paineis_resul(int quantidade_paineis_resul) {
        this.quantidade_paineis_resul = quantidade_paineis_resul;
    }

    public double getGeracao_kwh_resul() {
        return geracao_kwh_resul;
    }

    public void setGeracao_kwh_resul(double geracao_kwh_resul) {
        this.geracao_kwh_resul = geracao_kwh_resul;
    }

    public double getEconomia_reais_resul() {
        return economia_reais_resul;
    }

    public void setEconomia_reais_resul(double economia_reais_resul) {
        this.economia_reais_resul = economia_reais_resul;
    }

    public int getRoi_resul() {
        return roi_resul;
    }

    public void setRoi_resul(int roi_resul) {
        this.roi_resul = roi_resul;
    }

    public double getCusto_tot_resul() {
        return custo_tot_resul;
    }

    public void setCusto_tot_resul(double custo_tot_resul) {
        this.custo_tot_resul = custo_tot_resul;
    }

    public int getFk_con() {
        return fk_con;
    }

    public void setFk_con(int fk_con) {
        this.fk_con = fk_con;
    }
}
