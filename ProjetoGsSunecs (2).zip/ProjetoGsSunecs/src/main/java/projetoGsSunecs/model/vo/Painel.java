package projetoGsSunecs.model.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Painel {
	
    private int id_painel;
    private double comprimento;
    private double largura;
    private double potencia;
    private double preco;
    private int fk_empre;

    public Painel() {}

    public Painel(int id_painel, double comprimento, double largura, double potencia, double preco, int fk_empre) {
        this.id_painel = id_painel;
        this.comprimento = comprimento;
        this.largura = largura;
        this.potencia = potencia;
        this.preco = preco;
        this.fk_empre = fk_empre;
    }

    public int getId_painel() {
        return id_painel;
    }

    public void setId_painel(int id_painel) {
        this.id_painel = id_painel;
    }

    public double getComprimento() {
        return comprimento;
    }

    public void setComprimento(double comprimento) {
        this.comprimento = comprimento;
    }

    public double getLargura() {
        return largura;
    }

    public void setLargura(double largura) {
        this.largura = largura;
    }

    public double getPotencia() {
        return potencia;
    }

    public void setPotencia(double potencia) {
        this.potencia = potencia;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getFk_empre() {
        return fk_empre;
    }

    public void setFk_empre(int fk_empre) {
        this.fk_empre = fk_empre;
    }
}
