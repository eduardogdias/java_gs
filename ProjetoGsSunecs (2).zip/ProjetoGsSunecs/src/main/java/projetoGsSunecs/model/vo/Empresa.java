package projetoGsSunecs.model.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Empresa {
	
    private int id_empre;
    private String nome_empre;
    private String endereco_empre;
    private String tel_empre;
    private String cnpj_empre;
    private double valor_empre;

    public Empresa() {}

  
    public Empresa(int id_empre, String nome_empre, String endereco_empre, String cnpj_empre, double valor_empre) {
		this.id_empre = id_empre;
		this.nome_empre = nome_empre;
		this.endereco_empre = endereco_empre;
		this.cnpj_empre = cnpj_empre;
		this.valor_empre = valor_empre;
	}


    

	public Empresa(int id_empre, String nome_empre, String endereco_empre, String tel_empre, String cnpj_empre,
			double valor_empre) {
		this.id_empre = id_empre;
		this.nome_empre = nome_empre;
		this.endereco_empre = endereco_empre;
		this.tel_empre = tel_empre;
		this.cnpj_empre = cnpj_empre;
		this.valor_empre = valor_empre;
	}


	public int getId_empre() {
        return id_empre;
    }

    public void setId_empre(int id_empre) {
        this.id_empre = id_empre;
    }

    public String getNome_empre() {
        return nome_empre;
    }

    public void setNome_empre(String nome_empre) {
        this.nome_empre = nome_empre;
    }

    public String getEndereco_empre() {
        return endereco_empre;
    }

    public void setEndereco_empre(String endereco_empre) {
        this.endereco_empre = endereco_empre;
    }

    public String getTel_empre() {
        return tel_empre;
    }

    public void setTel_empre(String tel_empre) {
        this.tel_empre = tel_empre;
    }

    public String getCnpj_empre() {
        return cnpj_empre;
    }

    public void setCnpj_empre(String cnpj_empre) {
        this.cnpj_empre = cnpj_empre;
    }

	public double getValor_empre() {
		return valor_empre;
	}

	public void setValor_empre(double valor_empre) {
		this.valor_empre = valor_empre;
	}
    
    
    
}

