package projetoGsSunecs.model.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Consulta {
	
    private int id_con;
    private double consumo_mensal_kwh_con;
    private double gasto_mensal_reais_con;
    private double larg_area_con;
    private double compri_area_con;
    private int fk_usu;

    public Consulta() {}

    public Consulta(int id_con, double consumo_mensal_kwh_con, double gasto_mensal_reais_con, double larg_area_con, double compri_area_con, int fk_usu) {
        this.id_con = id_con;
        this.consumo_mensal_kwh_con = consumo_mensal_kwh_con;
        this.gasto_mensal_reais_con = gasto_mensal_reais_con;
        this.larg_area_con = larg_area_con;
        this.compri_area_con = compri_area_con;
        this.fk_usu = fk_usu;
    }

    public int getId_con() {
        return id_con;
    }

    public void setId_con(int id_con) {
        this.id_con = id_con;
    }

    public double getConsumo_mensal_kwh_con() {
        return consumo_mensal_kwh_con;
    }

    public void setConsumo_mensal_kwh_con(double consumo_mensal_kwh_con) {
        this.consumo_mensal_kwh_con = consumo_mensal_kwh_con;
    }

    public double getGasto_mensal_reais_con() {
        return gasto_mensal_reais_con;
    }

    public void setGasto_mensal_reais_con(double gasto_mensal_reais_con) {
        this.gasto_mensal_reais_con = gasto_mensal_reais_con;
    }

    public double getLarg_area_con() {
        return larg_area_con;
    }

    public void setLarg_area_con(double larg_area_con) {
        this.larg_area_con = larg_area_con;
    }

    public double getCompri_area_con() {
        return compri_area_con;
    }

    public void setCompri_area_con(double compri_area_con) {
        this.compri_area_con = compri_area_con;
    }

    public int getFk_usu() {
        return fk_usu;
    }

    public void setFk_usu(int fk_usu) {
        this.fk_usu = fk_usu;
    }
}
