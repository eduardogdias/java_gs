package projetoGsSunecs.model.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Usuario {
	
    private int id_usu;
    private String nome_usu;
    private String email_usu;
    private String cep_usu;

    public Usuario() {}

    public Usuario(int id_usu, String nome_usu, String email_usu, String cep_usu) {
        this.id_usu = id_usu;
        this.nome_usu = nome_usu;
        this.email_usu = email_usu;
        this.cep_usu = cep_usu;
    }

    public int getId_usu() {
        return id_usu;
    }

    public void setId_usu(int id_usu) {
        this.id_usu = id_usu;
    }

    public String getNome_usu() {
        return nome_usu;
    }

    public void setNome_usu(String nome_usu) {
        this.nome_usu = nome_usu;
    }

    public String getEmail_usu() {
        return email_usu;
    }

    public void setEmail_usu(String email_usu) {
        this.email_usu = email_usu;
    }

    public String getCep_usu() {
        return cep_usu;
    }

    public void setCep_usu(String cep_usu) {
        this.cep_usu = cep_usu;
    }
}

