package projetoGsSunecs.conexao;

public class Credenciais {

	public static final String user = "rm557886";
	public static final String pwd = "fiap2024";
}