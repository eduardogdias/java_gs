package projetoGsSunecs.view;

public class MensagemView {
	
	public void exibirMensagem(String mensagem) {
		System.out.println("Mensagem: " + mensagem);
	}

}
