package projetoGsSunecs.controller;

import java.util.ArrayList;

import projetoGsSunecs.model.bo.ResultadoBO;
import projetoGsSunecs.model.vo.Consulta;
import projetoGsSunecs.model.vo.Resultado;
import projetoGsSunecs.view.MensagemView;

public class ResultadoController {
	
	private ResultadoBO bo;
	private MensagemView view;
	private boolean retornoBo;
	
	public ResultadoController(ResultadoBO bo, MensagemView view) {
		this.bo = bo;
		this.view = view;
	}
	
	
	//insert
	public void salvarResultado(Resultado resultado) {
		retornoBo = bo.inserirBO(resultado);
		view.exibirMensagem((retornoBo) ? "Resultado cadastrado com sucesso!" : "Falha ao cadastrar resultado!");
	}
	
	public void salvarResultado(Consulta consulta) {
		System.out.println("Entrou no salvarResultado");
		System.out.println(consulta.getId_con());
		System.out.println(consulta.getConsumo_mensal_kwh_con());
		System.out.println(consulta.getGasto_mensal_reais_con());
		System.out.println(consulta.getLarg_area_con());
		System.out.println(consulta.getCompri_area_con());
		System.out.println(consulta.getFk_usu());
		
		ResultadoBO.calculoBO(consulta);
		
	}
	
	//read
	public ArrayList<Resultado> listarResultado() {
		return (ArrayList<Resultado>) bo.selecionarBO();
	}
		
	//update
	public void atualizarResultado(Resultado resultado, int id) {
		retornoBo = bo.atualizarBO(resultado, id);
		view.exibirMensagem((retornoBo) ? "Resultado atualizado com sucesso!" : "Falha ao atualizar resultado!");
	}

	//delete
	public void deletarResultado(int id) {
		retornoBo = bo.deletarBO(id);
		view.exibirMensagem((retornoBo) ? "Resultado deletado com sucesso!" : "Falha ao deletar resultado!");
	}

}
