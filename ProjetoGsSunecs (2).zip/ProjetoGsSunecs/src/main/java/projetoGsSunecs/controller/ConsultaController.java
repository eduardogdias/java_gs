package projetoGsSunecs.controller;

import java.util.ArrayList;

import projetoGsSunecs.model.bo.ConsultaBO;
import projetoGsSunecs.model.bo.ResultadoBO;
import projetoGsSunecs.model.vo.Consulta;
import projetoGsSunecs.view.MensagemView;

public class ConsultaController {
	
	private ConsultaBO bo;
	private MensagemView view;
	private boolean retornoBo;
	
	private ResultadoBO rbo;
	
	public ConsultaController(ConsultaBO bo, MensagemView view) {
		this.bo = bo;
		this.view = view;
	}
	
	
	//insert
	public void salvarConsulta(Consulta consulta) {
		retornoBo = bo.inserirBO(consulta);
		view.exibirMensagem((retornoBo) ? "Consulta cadastrada com sucesso!" : "Falha ao cadastrar consulta!");
		if(retornoBo) {
			System.out.println("Entrou no if");
			ResultadoController rc = new ResultadoController(rbo, view);
			rc.salvarResultado(consulta);
		}
	}
	
	
	//read
	public ArrayList<Consulta> listarConsulta() {
		return (ArrayList<Consulta>) bo.selecionarBO();
	}
		
	//update
	public void atualizarConsulta(Consulta consulta, int id) {
		retornoBo = bo.atualizarBO(consulta, id);
		view.exibirMensagem((retornoBo) ? "Consulta atualizada com sucesso!" : "Falha ao atualizar consulta!");
	}

	//delete
	public void deletarConsulta(int id) {
		retornoBo = bo.deletarBO(id);
		view.exibirMensagem((retornoBo) ? "Consulta deletada com sucesso!" : "Falha ao deletar consulta!");
	}

}
