package projetoGsSunecs.controller;

import java.util.ArrayList;

import projetoGsSunecs.model.bo.EmpresaBO;
import projetoGsSunecs.model.vo.Empresa;
import projetoGsSunecs.view.MensagemView;

public class EmpresaController {
	
	private EmpresaBO bo;
	private MensagemView view;
	private boolean retornoBo;
	
	public EmpresaController(EmpresaBO bo, MensagemView view) {
		this.bo = bo;
		this.view = view;
	}
	
	
	//insert
	public void salvarEmpresa(Empresa empresa) {
		retornoBo = bo.inserirBO(empresa);
		view.exibirMensagem((retornoBo) ? "Empresa cadastrada com sucesso!" : "Falha ao cadastrar empresa!");
	}
	
	
	//read
	public ArrayList<Empresa> listarEmpresa() {
		return (ArrayList<Empresa>) bo.selecionarBO();
	}
		
	//update
	public void atualizarEmpresa(Empresa empresa, int id) {
		retornoBo = bo.atualizarBO(empresa, id);
		view.exibirMensagem((retornoBo) ? "Empresa atualizada com sucesso!" : "Falha ao atualizada empresa!");
	}

	//delete
	public void deletarEmpresa(int id) {
		retornoBo = bo.deletarBO(id);
		view.exibirMensagem((retornoBo) ? "Empresa deletada com sucesso!" : "Falha ao deletada empresa!");
	}

}
