package projetoGsSunecs.controller;


import java.util.ArrayList;

import projetoGsSunecs.model.bo.UsuarioBO;
import projetoGsSunecs.model.vo.Usuario;
import projetoGsSunecs.view.MensagemView;

public class UsuarioController {
	
	private UsuarioBO bo;
	private MensagemView view;
	private boolean retornoBo;
	
	public UsuarioController(UsuarioBO bo, MensagemView view) {
		this.bo = bo;
		this.view = view;
	}
	
	
	//insert
	public void salvarUsuario(Usuario usuario) {
		retornoBo = bo.inserirBO(usuario);
		view.exibirMensagem((retornoBo) ? "Usuário cadastrado com sucesso!" : "Falha ao cadastrar usuário!");
	}
	
	
	//read
	public ArrayList<Usuario> listarUsuario() {
		return (ArrayList<Usuario>) bo.selecionarBO();
	}
		
	//update
	public void atualizarUsuario(Usuario usuario, int id) {
		retornoBo = bo.atualizarBO(usuario, id);
		view.exibirMensagem((retornoBo) ? "Usuário atualizado com sucesso!" : "Falha ao atualizar usuário!");
	}

	//delete
	public void deletarUsuario(int id) {
		retornoBo = bo.deletarBO(id);
		view.exibirMensagem((retornoBo) ? "Usuário deletado com sucesso!" : "Falha ao deletar usuário!");
	}

}
