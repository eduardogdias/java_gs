package projetoGsSunecs.controller;

import java.util.ArrayList;

import projetoGsSunecs.model.bo.PainelBO;
import projetoGsSunecs.model.vo.Painel;
import projetoGsSunecs.view.MensagemView;

public class PainelController {
	
	private PainelBO bo;
	private MensagemView view;
	private boolean retornoBo;
	
	public PainelController(PainelBO bo, MensagemView view) {
		this.bo = bo;
		this.view = view;
	}
	
	
	//insert
	public void salvarPainel(Painel painel) {
		retornoBo = bo.inserirBO(painel);
		view.exibirMensagem((retornoBo) ? "Painel cadastrado com sucesso!" : "Falha ao cadastrar painel!");
	}
	
	
	//read
	public ArrayList<Painel> listarPainel() {
		return (ArrayList<Painel>) bo.selecionarBO();
	}
		
	//update
	public void atualizarPainel(Painel painel, int id) {
		retornoBo = bo.atualizarBO(painel, id);
		view.exibirMensagem((retornoBo) ? "Painel atualizado com sucesso!" : "Falha ao atualizar painel!");
	}

	//delete
	public void deletarPainel(int id) {
		retornoBo = bo.deletarBO(id);
		view.exibirMensagem((retornoBo) ? "Painel deletado com sucesso!" : "Falha ao deletar painel!");
	}

}
